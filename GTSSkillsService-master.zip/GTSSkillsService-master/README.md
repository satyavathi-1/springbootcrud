# GSTSkillsService
GST Skills Service.  

# Required Tools to run project
Download and Install STS(Spring Tool Suite), MySql and Postman

#create a database with table name
table format present in gts_skills.sql
